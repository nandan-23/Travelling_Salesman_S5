import numpy as np
import time
import random

def calculate_total_distance(path, dist_matrix):
    total_distance = 0
    for i in range(len(path) - 1):
        total_distance += dist_matrix[path[i]][path[i+1]]
    total_distance += dist_matrix[path[-1]][path[0]]
    return total_distance

def nearest_neighbor_tsp(dist_matrix, start_city):
    n = len(dist_matrix)
    visited = [False] * n
    tour = []

    current_city = start_city
    tour.append(current_city)
    visited[current_city] = True

    total_distance = 0

    for _ in range(n - 1):
        nearest_city = None
        min_distance = float('inf')

        for next_city in range(n):
            if not visited[next_city] and dist_matrix[current_city][next_city] < min_distance:
                nearest_city = next_city
                min_distance = dist_matrix[current_city][next_city]

        tour.append(nearest_city)
        visited[nearest_city] = True
        total_distance += min_distance
        current_city = nearest_city

    #total_distance += dist_matrix[tour[-1]][tour[0]]
    #tour.append(tour[0])

    return tour, total_distance



def run_nearest_neighbor_tsp_multiple_times(distance_matrix, num_iterations):
    best_tour = None
    best_total_distance = float('inf')

    for i in range(num_iterations):
        starting_point = random.randint(0, len(distance_matrix) - 1)
        tour, total_distance = nearest_neighbor_tsp(distance_matrix, starting_point)

        if total_distance < best_total_distance:
            best_tour = tour
            best_total_distance = total_distance

    return best_tour, best_total_distance

def two_opt(path, dist_matrix, max_runtime, start_time):
    n = len(path)
    best_path = path
    best_distance = calculate_total_distance(best_path, dist_matrix)
    improved = True

    while improved:
        if time.time() - start_time > max_runtime:
            break
        improved = False
        for i in range(1, n - 2):
            for j in range(i + 1, n):
                if time.time() - start_time > max_runtime:
                    break
                if j - i == 1:
                    continue
                new_path = path[:i] + path[i:j][::-1] + path[j:]
                new_distance = calculate_total_distance(new_path, dist_matrix)
                if new_distance < best_distance:
                    best_path = new_path
                    best_distance = new_distance
                    improved = True
        path = best_path

    return best_path, best_distance


if __name__ == '__main__':
    input_type = input()
    n = int(input())
    coordinates = []
    dist_matrix = []

    for _ in range(n):
        x, y = map(float, input().split())
        coordinates.append((x, y))

    for _ in range(n):
        row = list(map(float, input().split()))
        dist_matrix.append(row)

    dist_matrix = np.array(dist_matrix)

    max_runtime = 280
    start_time = time.time()
    best_path = None
    best_distance = float('inf')

    while time.time() - start_time < max_runtime:
        current_path, current_distance = run_nearest_neighbor_tsp_multiple_times(dist_matrix, num_iterations= 1000)
        if time.time() - start_time < max_runtime:
            current_path, current_distance = two_opt(current_path, dist_matrix, max_runtime, start_time)
        if current_distance < best_distance:
            best_path = current_path
            best_distance = current_distance

    print(' '.join(map(str, best_path)))

    